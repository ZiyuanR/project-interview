/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.neu.controller;

import com.neu.edu.dao.UserDao;
import com.neu.edu.pojo.Login;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;
import org.springframework.web.servlet.view.RedirectView;

/**
 *
 * @author renziyuan
 */
public class AuthenticationController extends AbstractController {
    
    public AuthenticationController() {
    }
    
    protected ModelAndView handleRequestInternal(
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        HttpSession session = request.getSession();
        ModelAndView mv = null;
        
        String option = request.getParameter("option") == null ? "":request.getParameter("option");
        if(session.getAttribute("USER") == null && option.equals("")){
            return new ModelAndView("loginPage");
        }
        
        String username = request.getParameter("userName");
        String password = request.getParameter("password");
        UserDao userDao =  new UserDao();
        switch(option){
            case "login":
                Login loggedUser = userDao.authenticateLogin(username, password);
                if(loggedUser == null){
                    return new ModelAndView("loginPage");
                } else{
                    session.setAttribute("USER", loggedUser);
                    mv = new ModelAndView(new RedirectView("/lab5/messageHome.htm", false));
                }
                break;
            case "logout":
                session.invalidate();
                mv = new ModelAndView("loginPage");
                break;
            case "register":
                int registerUser = userDao.addUser(username, password);
                if(registerUser == 1){
                    Login loggeduser = new Login(username, password);
                    session.setAttribute("USER", loggeduser);
                    mv = new ModelAndView(new RedirectView("/lab5/messageHome.htm", false));
                } else{
                    mv = new ModelAndView("loginPage");
                }
                break;
            default:
                mv = new ModelAndView(new RedirectView("/lab5/messageHome.htm", false));
        }
        //return new ModelAndView("login", "user", new Login());
        //return new ModelAndView("login");
        return mv;
    }
    
}
