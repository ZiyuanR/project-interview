/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package part7.servlet;


import part7.dao.MovieDao;
import part7.pojo.MyDb;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


/**
 *
 * @author Hardik
 */
public class Part7Servlet extends HttpServlet {

    

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter out = resp.getWriter();
        HttpSession session = req.getSession(true);
        String choose = String.valueOf(req.getParameter("option"));
        if(choose.equals("add")){
            resp.setContentType("text/html;charset=UTF-8");

            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet movieStore</title>");  
            out.println("<script type='text/javascript'>"); 
            out.println("function Notice(){");
            out.println("var title = document.getElementById('title').value;");
            out.println("var actor = document.getElementById('actor').value;");
            out.println("var actress = document.getElementById('actress').value;");
            out.println("var genre = document.getElementById('genre').value;");
            out.println("var year = document.getElementById('year').value;");
            out.println("English(year);");
            out.println("}");
            out.println("function English(year){");
            out.println("var regex1 = /.*[a-zA-z].*/;");
            out.println("var result3 = regex1.test(year);");
//            out.println("if(title===\"\"||actor===\"\"||actress===\"\"||genre===\"\"||year===\"\"||result3===false){");
//            out.println("alert(\"Please Enter All the Information Below!\");}");
            out.println("if(result3===true){");
            out.println("alert(\"Year must be number!\");}");
            out.println("}</script>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet movieStore at </h1>");
            out.println("<form action='part7' method='get'>");
            out.println("Title: <input type='text' name='title' id='title' required='true'/><br><br>");
            out.println("Actor: <input type='text' name='actor' id='actor' required='true'/><br><br>");
            out.println("Actress: <input type='text' name='actress' id='actress' required='true'/><br><br>");
            out.println("Genre: <input type='text' name='genre' id='genre' required='true'/><br><br>");
            out.println("Year: <input type='text' name='year' id='year' required='true'/><br><br>");
            out.println("<input type='submit' value='Send' onclick='Notice()'/>");
            out.println("</form>");
            out.println("</body>");
            out.println("</html>");
        }
        if(choose.equals("check")){
            MovieDao moviedao = new MovieDao();
            ArrayList<MyDb> mydb;
            try {
                mydb = (ArrayList<MyDb>) moviedao.getMovies();
                req.setAttribute("moviedb", mydb);
                RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/WEB-INF/jsp/movie.jsp");
                requestDispatcher.forward(req, resp);
            } catch (Exception ex) {
                Logger.getLogger(Part7Servlet.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            
        }
        
        if(choose.equals("search")){
            resp.setContentType("text/html;charset=UTF-8");

            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Search Movies</title>"); 
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Searching Movies </h1>");
            out.println("<h3>Keyword: </h3>");
            out.println("<form action='part7_2' method='post'>");
            out.println("<input type='text' name='keyword' id='keyword' required='true'/><br>");
            out.println("<input type='radio' name='searchtype' value='title' id='searchtype' required='true'/>Search by Title<br><br>");
            out.println("<input type='radio' name='searchtype' value='actor' id='searchtype' required='true'/>Search by Actor<br><br>");
            out.println("<input type='radio' name='searchtype' value='genre' id='searchtype' required='true'/>Search by Genre<br><br>");
            out.println("<input type='submit' value='Search'/>");
            out.println("</form>");
            out.println("</body>");
            out.println("</html>");
            
            
        }

        
    }
        
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
          PrintWriter out = resp.getWriter();
          HttpSession session = req.getSession(true);
          String title = req.getParameter("title")==null?"":req.getParameter("title");
          String actor = req.getParameter("actor")==null?"":req.getParameter("actor");
          String actress = req.getParameter("actress")==null?"":req.getParameter("actress");
          String genre = req.getParameter("genre")==null?"":req.getParameter("genre");
          String year = req.getParameter("year");
          boolean english = false;
          english = isEnglish(year);
          if(english){
            req.getRequestDispatcher("/part7_1.html").forward(req, resp);
          }
          MyDb db = new MyDb();
          db.setTitle(title);
          db.setActor(actor);
          db.setActress(actress);
          db.setGenre(genre);
          db.setYear(Integer.parseInt(year));
          
          MovieDao moviedao = new MovieDao();
          moviedao.addMovies(db);
          session.setAttribute("movietitle", title);
          
          RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/WEB-INF/jsp/movienotice.jsp");
          requestDispatcher.forward(req,resp);
          }
          public boolean isEnglish(String str){
            //【含有英文】true
            String regex1 = ".*[a-zA-z].*";  
            boolean result3 = str.matches(regex1);
            return result3;
    }
    }
    


