/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package part7.servlet;


import part7.dao.MovieDao;
import part7.pojo.MyDb;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


/**
 *
 * @author Hardik
 */
public class Part7_2Servlet extends HttpServlet {

    

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter out = resp.getWriter();
        HttpSession session = req.getSession(true);
        
        String keyword = req.getParameter("keyword")==null?"":req.getParameter("keyword");
        String searchtype = req.getParameter("searchtype")==null?"":req.getParameter("searchtype");
//        if(keyword.equals("")||searchtype.equals("")){
//            req.getRequestDispatcher("/part7_1.html").forward(req, resp);
//        }
        MovieDao moviedao = new MovieDao();
        List<MyDb> titledb = (List<MyDb>) moviedao.searchMovies(keyword, searchtype);
        req.setAttribute("searchdb", titledb);
        RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/WEB-INF/jsp/moviesearch.jsp");
        requestDispatcher.forward(req, resp);
    }
}                  