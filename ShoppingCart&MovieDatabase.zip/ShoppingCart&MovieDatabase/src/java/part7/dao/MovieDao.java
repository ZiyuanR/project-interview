/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package part7.dao;

import part7.pojo.MyDb;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.dbutils.DbUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

/**
 *
 * @author renziyuan
 */
public class MovieDao {
    public List<MyDb> getMovies() throws Exception {
        Connection connection = null;
        List<MyDb> movieList = null;
            try{
                Dao dbdao = new Dao();
                connection = dbdao.getConnection();
                QueryRunner queryRunner = new QueryRunner();
                ResultSetHandler<List<MyDb>> mydb = new BeanListHandler<MyDb>(MyDb.class);
                String query = "SELECT * FROM movie";
                movieList = queryRunner.query(connection, query, mydb);
                } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        finally {
            try {
                DbUtils.close(connection);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return movieList;
    }
           
    
    public int addMovies(MyDb mydb) {
        Connection connection = null;
        int result = 0;
        try {
            Dao dbdao = new Dao();
            connection = dbdao.getConnection();
            QueryRunner queryRunner = new QueryRunner();
            String query = "INSERT INTO movie (title,actor,actress,genre,year) VALUES (?,?,?,?,?)";
            result = queryRunner.update(connection, query, mydb.getTitle(),mydb.getActor(), mydb.getActress(), mydb.getGenre(), mydb.getYear());
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
        finally {
            try {
                DbUtils.close(connection);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return result;
    }
    
    public List<MyDb> searchMovies(String keyword, String searchtype){
        Connection connection = null;
        List<MyDb> searchList = null;
        try{
                Dao dbdao = new Dao();
                connection = dbdao.getConnection();
                QueryRunner queryRunner = new QueryRunner();
                ResultSetHandler<List<MyDb>> mydb = new BeanListHandler<MyDb>(MyDb.class);
                String query = "SELECT * FROM movie where "+searchtype+" like '%"+keyword+"%'";
                searchList = queryRunner.query(connection, query, mydb);
                } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        finally {
            try {
                DbUtils.close(connection);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        return searchList;
    }
}
