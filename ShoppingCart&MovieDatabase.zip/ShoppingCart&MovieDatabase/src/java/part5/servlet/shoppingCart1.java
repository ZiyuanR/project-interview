package part5.servlet;

import part5.pojo.Product;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.RequestDispatcher;

public class shoppingCart1 extends HttpServlet {

    
    public void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession(true);
        //HttpSession session = request.getSession();

        String option = request.getParameter("option");
        String[] pro = request.getParameterValues("product");
        String[] split = new String[2];

        String delimeter = "-";
        
        HashMap<String, Integer> shoppingCart = new HashMap<String, Integer>();
        if(session.getAttribute("cartpage") != null){
            shoppingCart = (HashMap<String, Integer>)session.getAttribute("cartpage");
        }
        else{
            shoppingCart = new HashMap<String,Integer>();
        }
        out.println("<html>");
        out.println("<head>");
        out.println("<title> Type Children's Names </title>");
        out.println("<meta charset='UTF-8'>");
        out.println("</head>");
        out.println("<body>");
         if(option.equals("add")==true){
             if(pro==null){
            RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/errorPage_1.jsp");
            requestDispatcher.forward(request, response);
            }
                ArrayList<Product> noticeProduct  = new ArrayList<Product>();

                
                for(int i=0; i<pro.length; i++){
                    split = pro[i].split(delimeter);
                    Product product = new Product();
                    product.setName(split[0]);
                    product.setPrice(split[1]);
                    noticeProduct.add(product);
                    session.setAttribute("noticepage",noticeProduct);
                    boolean b = shoppingCart.containsKey(pro[i]);
                    if(b) {
                          int count = shoppingCart.get(pro[i])+1;
                          shoppingCart.put(pro[i],count);
                    }else{
                          shoppingCart.put(pro[i],1);
                    }
                
                    }
            session.setAttribute("cartpage",shoppingCart);
//	    request.getRequestDispatcher("/notice.jsp").forward(request, response);
            RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/notice.jsp");
            requestDispatcher.forward(request, response);
        }
        else if(option.equals("delete")){
            String[] itemdelete = request.getParameterValues("item_delete");
            for(int i=0; i<itemdelete.length; i++){
                    if(shoppingCart.get(itemdelete[i])>1){
                        int number = shoppingCart.get(itemdelete[i])-1;
                        shoppingCart.put(itemdelete[i], number);
                        
                    } else{
                        shoppingCart.remove(itemdelete[i]);
                    }
            
            }
            session.setAttribute("cartpage",shoppingCart);
            //request.getRequestDispatcher("cart.jsp").forward(request, response);
            RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/cartdisplay.jsp");
            requestDispatcher.forward(request, response);
        }
         
        out.println("</body>");
        out.println("</html>");

    }
}