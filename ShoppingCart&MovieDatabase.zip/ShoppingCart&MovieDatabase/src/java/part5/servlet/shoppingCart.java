package part5.servlet;

import part5.pojo.Product;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.RequestDispatcher;

public class shoppingCart extends HttpServlet {

    
    public void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession(true);
        //HttpSession session = request.getSession();

        String option = request.getParameter("option");
        String[] pro = request.getParameterValues("product");
        String[] split;
        String delimeter = "-";

        ArrayList<Product> shoppingCart = new ArrayList<Product>();
        if(session.getAttribute("cartpage") != null){
            shoppingCart = (ArrayList<Product>)session.getAttribute("cartpage");
        }
        else{
            shoppingCart = new ArrayList<Product>();
        }
        out.println("<html>");
        out.println("<head>");
        out.println("<title> Type Children's Names </title>");
        out.println("<meta charset='UTF-8'>");
        out.println("</head>");
        out.println("<body>");
         if(option.equals("add")){
                ArrayList<Product> noticeProduct  = new ArrayList<Product>();

                
                for(int i=0; i<pro.length; i++){
                    split = pro[i].split(delimeter);
                    Product product = new Product();
                    product.setName(split[0]);
                    product.setPrice(split[1]);
                    noticeProduct.add(product);
                    session.setAttribute("noticepage",noticeProduct);
                }
//                for(Product p:shoppingCart){
//                    for(Product notice:noticeProduct){
//                        if(p.getName().equals(notice.getName())){
//                            noticeProduct.remove(notice);
//                        }
//                    }
//                }
//                for(Product clean:noticeProduct){
//                    shoppingCart.add(clean);
//                }
                
            session.setAttribute("cartpage",shoppingCart);
//	    session.setAttribute("noticepage",noticeProduct);
//	    request.getRequestDispatcher("notice.jsp").forward(request, response);
            RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/notice.jsp");
            requestDispatcher.forward(request, response);
        
    }
        else if(option.equals("delete")){
            String[] namedelete = request.getParameterValues("name_delete");
            for(int i=0; i<namedelete.length; i++){
                for(int j=0; j<shoppingCart.size(); j++){
                    if(namedelete[i].equals(shoppingCart.get(j).getName())==true){
                        shoppingCart.remove(j);
                }
            }
        }
            session.setAttribute("cartpage",shoppingCart);
            //request.getRequestDispatcher("cart.jsp").forward(request, response);
            RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/cart.jsp");
            requestDispatcher.forward(request, response);
        }
         
        out.println("</body>");
        out.println("</html>");

    }
}