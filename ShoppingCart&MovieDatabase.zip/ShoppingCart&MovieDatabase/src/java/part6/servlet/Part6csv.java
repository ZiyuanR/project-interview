/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package part6.servlet;

import part6.dao.CSVDAO;
import part6.pojo.SalesOrder;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author 41882
 */
public class Part6csv extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */



    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html;charset=UTF-8");
        String fileName = req.getParameter("fileName");
        String option = req.getParameter("option");
        if (option.equals("search") & fileName.equalsIgnoreCase("SalesOrder")) {
            CSVDAO csvdao = new CSVDAO();
            List<SalesOrder> list = csvdao.getCSV();
            ArrayList<String> tablehead = csvdao.getTableHead();
            try {

                req.setAttribute("CSV", list);
                req.setAttribute("tablehead", tablehead);
                req.getRequestDispatcher("/displayCSV.jsp").forward(req, resp);

            } catch (Exception ex) {
                System.out.println("Exception: " + ex.getMessage());
            }
        } else{
            req.getRequestDispatcher("/errorPage.jsp").forward(req, resp);
        }    
    }

}

