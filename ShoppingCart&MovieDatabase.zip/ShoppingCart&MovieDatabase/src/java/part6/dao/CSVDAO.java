/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package part6.dao;

import part6.pojo.SalesOrder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

/**
 *
 * @author 41882
 */
public class CSVDAO {
    public List<SalesOrder> getCSV (){
        Connection connection=null;
        List<SalesOrder> result = null;
        try {
             
            Class.forName("org.relique.jdbc.csv.CsvDriver");
            String csvPath="/Users/renziyuan/NetBeansProjects/Assignment02/";

            // Create a connection. The first command line parameter is
            // the directory containing the .csv files.
            // A single connection is thread-safe for use by several threads.

            connection = DriverManager.getConnection("jdbc:relique:csv:"+ csvPath);
            // Create a Statement object to execute the query with.
            // A Statement is not thread-safe.
            //Statement stmt = conn.createStatement();
            QueryRunner queryRunner = new QueryRunner();
            ResultSetHandler<List<SalesOrder>> hander = new BeanListHandler<SalesOrder>(SalesOrder.class);
            String query = "SELECT * FROM SalesOrder";
//            String query = "SELECT * FROM" + fileName;
            result = queryRunner.query(connection, query,hander);
            // Select the ID and NAME columns from sample.csv
            //ResultSet rs = stmt.executeQuery("SELECT * FROM "+fileName);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
            return result;
    }
    
    public ArrayList<String> getTableHead(){
        ArrayList<String> tablehead = new ArrayList<String>();
        String csvPath = "/Users/renziyuan/NetBeansProjects/Assignment02/";
   
    try{
            Class.forName("org.relique.jdbc.csv.CsvDriver");
            
            Connection conn = DriverManager.getConnection("jdbc:relique:csv:"+csvPath);
            Statement stmt = conn.createStatement();
            ResultSet results = stmt.executeQuery("SELECT * FROM SalesOrder");
            int columns = results.getMetaData().getColumnCount();
            
            for(int i=1; i<=columns; i++){
               //拿到表头
               
                tablehead.add(results.getMetaData().getColumnName(i));
            }
    
    }catch(Exception ex){
            System.out.println("Exception: "+ex.getMessage());
            
        }
    return tablehead;
    }
}
